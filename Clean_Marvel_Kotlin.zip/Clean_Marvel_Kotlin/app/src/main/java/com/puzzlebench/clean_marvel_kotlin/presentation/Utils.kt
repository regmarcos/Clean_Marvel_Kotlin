package com.puzzlebench.clean_marvel_kotlin.presentation

const val TAG: String = "TAG"
const val DOT: String = "."
const val NO_DESCRIPTION = "No description"
const val SCREEN_PERCENTAGE = 0.8
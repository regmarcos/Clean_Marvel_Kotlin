package com.puzzlebench.clean_marvel_kotlin.presentation.base


abstract class Presenter<out V>(val view: V)

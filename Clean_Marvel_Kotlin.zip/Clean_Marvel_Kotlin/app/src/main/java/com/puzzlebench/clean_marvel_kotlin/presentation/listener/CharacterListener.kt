package com.puzzlebench.clean_marvel_kotlin.presentation.listener

import com.puzzlebench.cmk.domain.model.Character

typealias CharacterListener = (Character) -> Unit

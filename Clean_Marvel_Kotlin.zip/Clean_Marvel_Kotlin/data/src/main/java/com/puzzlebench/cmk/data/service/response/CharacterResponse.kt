package com.puzzlebench.cmk.data.service.response

class CharacterResponse(
        val id: Int?,
        val name: String?,
        val description: String?,
        val thumbnail: ThumbnailResponse
)
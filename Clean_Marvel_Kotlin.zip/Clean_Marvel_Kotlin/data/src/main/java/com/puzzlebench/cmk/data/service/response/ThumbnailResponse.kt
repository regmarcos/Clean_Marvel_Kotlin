package com.puzzlebench.cmk.data.service.response


class ThumbnailResponse(
        var path: String?,
        var extension: String?
)
package com.puzzlebench.cmk.domain.model

open class ComicSummary (
        resourceURI: String,
        name: String
)
